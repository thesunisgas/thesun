#!/usr/bin/env bash
npm run build
